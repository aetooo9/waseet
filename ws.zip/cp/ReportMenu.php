 <div class="col-lg-3 ds">
                  

                       <!-- USERS ONLINE SECTION -->
						<h3>التقارير</h3>
                      <!-- First Member -->
                      <div class="desc">
                      	<div class="details">
                      		<p><a href="Report1.php">تقرير الموردين</a>
                      		</p>
                      	</div>
                      </div>
                      <!-- Second Member -->
                      <div class="desc">
                      	<div class="details">
                      		<p><a href="Report2.php">تقرير الارادات</a>
                      	</div>
                      </div>
					   <div class="desc">
                      	<div class="details">
                      		<p><a href="Report3.php">تقرير الحسابات</a>
                      	</div>
                      </div>
                      
</div><!-- /col-lg-3 -->