<div class="social">
<i class="fa fa-facebook" ></i>
<i class="fa fa-twitter" ></i>
<i class="fa fa-youtube" ></i>
</div>